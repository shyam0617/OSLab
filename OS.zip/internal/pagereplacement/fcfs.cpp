//PageReplacement algorithm

#include<bits/stdc++.h>
using namespace std;

int hit=0;
int fault=0;

void print(vector<int>&frames)
{  
   cout<<"updated : "<<endl;
   for(auto i:frames)
   cout<<i<<" ";
   cout<<endl;
}
int main()
{
   int n;
   cout<<"enter no.of processors : "<<endl;
   cin>>n;
   
   vector<int>p(n);
   
   for(int i=0;i<n;i++)
   {
      cin>>p[i];
   }
   
   int f;
   cout<<"enter no.of frames : "<<endl;
   cin>>f;
   
   vector<int>frames;
   
   int count=0;
   
   for(int i=0;i<n;i++)
   {  
     
      auto t=find(frames.begin(),frames.end(),p[i]);
      
      if(t!=frames.end())
      {
         cout<<"hit :"<<p[i]<<endl;
         hit++;
         print(frames);
      }
      else
      {
      fault++;
      if(frames.size()!=f)
      { 
        frames.push_back(p[i]);
        print(frames);
      }
      else
      { 
        frames[count]=p[i];
        count++;
        count=count%f;
        print(frames);
      }
      }
   }
   cout<<"hits : "<<hit<<endl;
   cout<<"faults : "<<fault;
}
   
      
   
