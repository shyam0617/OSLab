//PageReplacement algorithm optimal page

#include<bits/stdc++.h>
using namespace std;

int hit=0;
int fault=0;

void print(vector<int>&frames)
{
   cout<<"frames : "<<endl;
   for(int val : frames)
   cout<<val;
   cout<<endl;
}

int find(vector<int>dummy,vector<int>p,int y)
{
   for(int i=y+1;i<p.size();i++)
   {
      for(int k=0;k<dummy.size();k++)
      {
          if(dummy.size()==1)
          return dummy[0];
          if(dummy[k]==p[i])
          {
            dummy.erase(dummy.begin()+k);
          }
      }
   }
   return dummy[0];
}
int main()
{
   int n;
   cout<<"enter no.of processors : "<<endl;
   cin>>n;
   
   vector<int>p(n);
   
   cout<<"enter processors : "<<endl;
   
   for(int i=0;i<n;i++)
   {
      cin>>p[i];
   }
   
   int f;
   cout<<"enter no.of frames : "<<endl;
   cin>>f;
   
   vector<int>frames;
   
   for(int i=0;i<n;i++)
   {
       auto t=find(frames.begin(),frames.end(),p[i]);
       
       if(t!=frames.end())
       {
          cout<<"hit : "<<p[i]<<endl;
          hit++;
          print(frames);
       }
       else
       {
         fault++;
         if(frames.size()!=f)
         {
            frames.push_back(p[i]);
            print(frames);
         }
         else
         {
            vector<int>dummy;
            dummy=frames;
            int k=find(dummy,p,i);
            for(int j=0;j<frames.size();j++)
            {
                if(frames[j]==k)
                {
                frames[j]=p[i];
                break;
                }
            }
            print(frames);
         }
      }
  
  }
     cout<<"no.of hits : "<<hit<<endl;
     cout<<"no.of faults : "<<fault<<endl;         
  
}
  
   
          
