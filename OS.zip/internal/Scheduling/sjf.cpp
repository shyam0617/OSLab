//shortest job first

#include<bits/stdc++.h>
using namespace std;

struct process{

   int pid,at,bt,ct,tat,wt;
};


void sjf(process *p,int n)
{
  
  int count=0;
  int time=0;
  while(count<n)
  {
     int max=INT_MAX;
     int selected=-1;
   
   for(int i=0;i<n;i++)
   {
     if(p[i].at<=time && p[i].bt<max && p[i].bt!=0)
     {
         max=p[i].bt;
         selected=i;
     }
   }
     if(selected==-1)
     {
        time++;
     }
     else
     {
       time=time+p[selected].bt;
       p[selected].ct=time;
       p[selected].tat=p[selected].ct-p[selected].at;
       p[selected].wt=p[selected].tat-p[selected].bt;
       p[selected].bt=0;
       count++;
     }
  }
}
void display(process *p,int n)
{
   cout<<"pid  ct  tat  wt "<<endl;
   for(int i=0;i<n;i++)
   {
      cout<<p[i].pid<<"  "<<p[i].ct<<"  "<<p[i].tat<<"  "<<p[i].wt<<endl;
   }
}

int main()
{
   int n;
   cout<<"enter no.of processes : ";
   cin>>n;
   
   process p[n];
   
   cout<<"enter process id,arrival time,burst time : "<<endl;
   
   for(int i=0;i<n;i++)
   {
      cin>>p[i].pid>>p[i].at>>p[i].bt;
   }
   
   sjf(p,n);
   display(p,n);
}
