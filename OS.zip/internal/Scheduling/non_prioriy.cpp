//non_priemptive_priority

#include<bits/stdc++.h>
using namespace std;

struct process{

   int pid,prt,at,bt,ct,tat,wt;
};


void priemptive(process *p,int n)
{
  
  int count=0;
  int time=0;
  while(count<n)
  {
     int lowpriority=INT_MAX;
     int selected=-1;
   
   for(int i=0;i<n;i++)
   {
     if(p[i].at<=time && p[i].prt<lowpriority && p[i].bt!=0)
     {
         lowpriority=p[i].prt;
         selected=i;
     }
   }
     if(selected==-1)
     {
        time++;
     }
     else
     {
       time=time+p[selected].bt;
       p[selected].ct=time;
       p[selected].tat=p[selected].ct-p[selected].at;
       p[selected].wt=p[selected].tat-p[selected].bt;
       p[selected].bt=0;
       count++;
     }
  }
}
void display(process *p,int n)
{
   cout<<"pid  ct  tat  wt "<<endl;
   for(int i=0;i<n;i++)
   {
      cout<<p[i].pid<<"  "<<p[i].ct<<"  "<<p[i].tat<<"  "<<p[i].wt<<endl;
   }
}

int main()
{
   int n;
   cout<<"enter no.of processes : ";
   cin>>n;
   
   process p[n];
   
   cout<<"enter process id,priority,arrival time,burst time : "<<endl;
   
   for(int i=0;i<n;i++)
   {
      cin>>p[i].pid>>p[i].prt>>p[i].at>>p[i].bt;
   }
   
   priemptive(p,n);
   display(p,n);
}
