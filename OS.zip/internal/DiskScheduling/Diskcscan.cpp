//DiskScheduling algorithm Cscan

#include<bits/stdc++.h>
using namespace std;

int left(vector<int>&ans,int p,int head,int n)
{
  int sum=0;
  sum+=abs(ans[p]-head);
  
  for(int i=p;i>0;i--)
  {
     sum+=abs(ans[i]-ans[i-1]);
  }
  
  sum+=abs(ans[0]-ans[n-1]);
  
  for(int i=n-1;i>p+1;i--)
  {
     sum+=abs(ans[i]-ans[i-1]);
  }
  
  return sum;
}

int right(vector<int>&ans,int p,int head,int n)
{
   int sum=0;
   sum+=abs(ans[p]-head);
   
   for(int i=p;i<n-1;i++)
   {
     sum+=abs(ans[i]-ans[i+1]);
   }
   sum+=abs(ans[n-1]-ans[0]);
   
   for(int i=0;i<p-1;i++)
   {
     sum+=abs(ans[i]-ans[i+1]);
   }
   return sum;
}

int main()
{
cout<<"enter no.of processors : "<<endl;
  
  int n;
  cin>>n;
  
  cout<<"enter processors : "<<endl;
  
  vector<int>ans(n);
  
  for(auto i=0;i<n;i++)
  {
      cin>>ans[i];
  }
  
  ans.push_back(0);
  ans.push_back(199);
  n=n+2;
  
  sort(ans.begin(),ans.end());
  
  int t;
  
  cout<<"enter head postition : "<<endl;
  cin>>t;
  
  int z;
  
  cout<<"enter +1 for moving head in left else -1"<<endl;
  cin>>z;
  
  for(int i=0;i<n-1;i++)
  {
     if(t>ans[i] && t<ans[i+1])
     {
         if(z==1)
         cout<<left(ans,i,t,n);
         else
         cout<<right(ans,i+1,t,n);
     }
  }
}
  
