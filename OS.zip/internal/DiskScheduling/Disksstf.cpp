//DiskScheduling algorithm sstf

#include<bits/stdc++.h>
using namespace std;

int find(vector<int>&ans,int value)
{
   int index=-1;
   int m=INT_MAX;
   for(int i=0;i<ans.size();i++)
   {
      int d=abs(ans[i]-value);
      
      if(d<m)
      {
         index=i;
         m=d;
      }
   }
   return index;
   
}
void sstf(vector<int>&ans,int initial)
{
   int movements=0;
   int current=initial;
   
   while(!ans.empty())
   {
      int index=find(ans,current);
      
      int next=ans[index];
      
      movements+=abs(next-current);
      
      current=next;
      
      ans.erase(ans.begin()+index);
   }
   
   cout<<movements;
}
          
int main()
{
   int n;
   cout<<"enter no.of processors : "<<endl;
   cin>>n;
   
   vector<int> ans(n);
   
   cout<<"enter processors : "<<endl;
   
   for(int i=0;i<n;i++)
   {
      cin>>ans[i];
   }
   
   cout<<"enter initial head position : "<<endl;
   
   int t;
   
   cin>>t;
   
   sstf(ans,t);
}
   
   
   
