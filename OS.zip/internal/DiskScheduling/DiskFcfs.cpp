//DiskScheduling algorithm

#include<bits/stdc++.h>
using namespace std;

int main()
{ 
  int n;
  cout<<"enter how many number of processors : "<<endl;
  cin>>n;
  vector<int>p;
  
  cout<<"enter processors request :"<<endl;
  for(auto i=0;i<n;i++)
  { 
     int k;
     cin>>k;
     p.push_back(k);
  }
  
  int t;
  cout<<"enter head position : "<<endl;
  cin>>t;
  
  int ans=abs(p[0]-t);
  
  for(int i=1;i<n;i++)
  {
      ans+=abs(p[i]-p[i-1]);
  }
  
  cout<<"Total no.of head movements : "<<endl;
  cout<<ans;
}
  
