//Shyamsunder
//memory management firstFit

#include<bits/stdc++.h>
using namespace std;

int main()
{
  int n,t;
  
  cout<<"enter no.of processors : "<<endl;
  cin>>n;
  
  vector<int>p(n);
  
  cout<<"enter processors : "<<endl;
  
  for(int i=0;i<n;i++)
  cin>>p[i];
  
  cout<<"enter no.of blocks : "<<endl;
  cin>>t;
  
  vector<int>b(t);
  
  cout<<"enter blocks : "<<endl;
  for(int i=0;i<t;i++)
  cin>>b[i];
  
    vector<int>all(n,-1);//p-b
    vector<int>a(t,-1);//to check memorey occupied or not
  
 
  
  for(int i=0;i<n;i++)//p
  {
     for(int j=0;j<t;j++)//b
     {
         if(b[j]>=p[i] && a[j]==-1)
         {
            a[j]=0;
            all[i]=j+1;
            break;
          }  
     }
       
  }
 
       cout<<"process id\tproccess_size\tmem_block"<<endl;
       
       for(int i=0;i<n;i++){
       cout<<"P"<<i+1<<"\t\t\t"<<p[i]<<"\t\t\t";
       if(all[i]!=-1)cout<<"block-"<<all[i]<<endl;
       else
       cout<<"Notallocated : "<<endl;
     
       }
}
       
          
          
          
