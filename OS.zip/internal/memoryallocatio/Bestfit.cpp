//Shyamsunder
//MemoryAllocation Bestfit

#include<bits/stdc++.h>
using namespace std;

void bestfit(vector<int>&p,int pn,vector<int>&b,int bn)
{
  vector<int>a(bn,-1);
  
  vector<int>all(pn,-1);
  
  int frag=0;
  
  for(int i=0;i<pn;i++)
  { 
    int m=INT_MAX;
    bool f=false;
    int index;
    for(int j=0;j<bn;j++)
    {
       if(b[j]>=p[i] && b[j]<m && a[j]==-1)
       {
           index=j;
           m=b[j];
           f=true;
       }
    }
    if(f)
    {
      a[index]=0;
      all[i]=index+1;
      frag+=b[index]-p[i];
    }     
 }
 
 cout<<"process_id\tprocess_size\tmem_block"<<endl;
 for(int i=0;i<pn;i++)
 {
   cout<<"p"<<i+1<<"\t\t\t"<<p[i]<<"\t\t\t";
   if(all[i]==-1)
   cout<<"not allocated : "<<endl;
   else
   cout<<all[i]<<endl;
 }
 
 cout<<"internal fragmentation : "<<frag<<endl;
}
int main()
{
   int n,t;
  
  cout<<"enter no.of processors : "<<endl;
  cin>>n;
  
  vector<int>p(n);
  
  cout<<"enter processors : "<<endl;
  
  for(int i=0;i<n;i++)
  cin>>p[i];
  
  cout<<"enter no.of blocks : "<<endl;
  cin>>t;
  
  vector<int>b(t);
  
  cout<<"enter blocks : "<<endl;
  
  for(int i=0;i<t;i++)
  cin>>b[i];
  
  bestfit(p,n,b,t);
  
}

